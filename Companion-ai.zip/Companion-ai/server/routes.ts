import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { enhancedResearchService } from "./services/enhanced-research";
import { researchRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/research", async (req, res) => {
    try {
      const { query } = researchRequestSchema.parse(req.body);
      
      const result = await enhancedResearchService.performEnhancedResearch(query);
      
      // Save to storage
      await storage.saveResearchQuery({
        query: query,
        summary: result.summary,
        sourceCount: result.sourceCount,
        processingTime: result.processingTime,
      });

      res.json(result);
    } catch (error) {
      console.error("Research API error:", error);
      
      if (error instanceof Error) {
        res.status(500).json({ 
          error: error.message,
          heard: req.body?.query || "",
        });
      } else {
        res.status(500).json({ 
          error: "An unexpected error occurred",
          heard: req.body?.query || "",
        });
      }
    }
  });

  app.get("/api/recent-queries", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const queries = await storage.getRecentQueries(limit);
      res.json(queries);
    } catch (error) {
      console.error("Recent queries API error:", error);
      res.status(500).json({ error: "Failed to fetch recent queries" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
