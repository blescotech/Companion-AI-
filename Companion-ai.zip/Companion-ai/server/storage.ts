import { type User, type InsertUser, type ResearchQuery, type InsertResearchQuery } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  saveResearchQuery(query: InsertResearchQuery): Promise<ResearchQuery>;
  getRecentQueries(limit?: number): Promise<ResearchQuery[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private researchQueries: Map<string, ResearchQuery>;

  constructor() {
    this.users = new Map();
    this.researchQueries = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async saveResearchQuery(query: InsertResearchQuery): Promise<ResearchQuery> {
    const id = randomUUID();
    const researchQuery: ResearchQuery = {
      id,
      query: query.query,
      summary: query.summary,
      sourceCount: query.sourceCount || null,
      processingTime: query.processingTime || null,
      createdAt: new Date(),
    };
    this.researchQueries.set(id, researchQuery);
    return researchQuery;
  }

  async getRecentQueries(limit = 10): Promise<ResearchQuery[]> {
    const queries = Array.from(this.researchQueries.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
    return queries;
  }
}

export const storage = new MemStorage();
