import { ResearchService } from './research';
import { notionService } from './notion';
import { outlookService } from './outlook';

export interface EnhancedSearchResult {
  summary: string;
  sourceCount: string;
  processingTime: string;
  type: 'research' | 'notion' | 'email' | 'calendar' | 'mixed';
  notionPages?: any[];
  emails?: any[];
  events?: any[];
}

export class EnhancedResearchService extends ResearchService {
  
  async performEnhancedResearch(query: string): Promise<EnhancedSearchResult> {
    const startTime = Date.now();
    
    try {
      // Analyze the query to determine what services to use
      const queryType = this.analyzeQuery(query);
      
      let summary = '';
      let notionPages: any[] = [];
      let emails: any[] = [];
      let events: any[] = [];
      let sourceCount = '0';
      
      switch (queryType) {
        case 'notion':
          notionPages = await this.handleNotionQuery(query);
          summary = this.formatNotionSummary(notionPages, query);
          sourceCount = notionPages.length.toString();
          break;
          
        case 'email':
          emails = await this.handleEmailQuery(query);
          summary = this.formatEmailSummary(emails, query);
          sourceCount = emails.length.toString();
          break;
          
        case 'calendar':
          events = await this.handleCalendarQuery(query);
          summary = this.formatCalendarSummary(events, query);
          sourceCount = events.length.toString();
          break;
          
        case 'mixed':
          // Search multiple services
          const results = await Promise.allSettled([
            this.handleNotionQuery(query),
            this.handleEmailQuery(query),
            this.handleCalendarQuery(query)
          ]);
          
          if (results[0].status === 'fulfilled') notionPages = results[0].value;
          if (results[1].status === 'fulfilled') emails = results[1].value;
          if (results[2].status === 'fulfilled') events = results[2].value;
          
          summary = this.formatMixedSummary(notionPages, emails, events, query);
          sourceCount = (notionPages.length + emails.length + events.length).toString();
          break;
          
        default:
          // Fall back to regular web research
          const researchResult = await super.performResearch(query);
          return {
            ...researchResult,
            type: 'research'
          };
      }
      
      const processingTime = `${Date.now() - startTime}ms`;
      
      return {
        summary,
        sourceCount,
        processingTime,
        type: queryType,
        notionPages,
        emails,
        events
      };
      
    } catch (error: any) {
      console.error('Enhanced research error:', error);
      // Fall back to regular research if integrations fail
      const researchResult = await super.performResearch(query);
      return {
        ...researchResult,
        type: 'research'
      };
    }
  }
  
  private analyzeQuery(query: string): 'research' | 'notion' | 'email' | 'calendar' | 'mixed' {
    const lowerQuery = query.toLowerCase();
    
    // Notion keywords
    const notionKeywords = ['notion', 'document', 'page', 'note', 'workspace', 'save to notion'];
    const hasNotionKeywords = notionKeywords.some(keyword => lowerQuery.includes(keyword));
    
    // Email keywords
    const emailKeywords = ['email', 'mail', 'message', 'inbox', 'send email', 'compose'];
    const hasEmailKeywords = emailKeywords.some(keyword => lowerQuery.includes(keyword));
    
    // Calendar keywords
    const calendarKeywords = ['calendar', 'meeting', 'appointment', 'schedule', 'event', 'create meeting'];
    const hasCalendarKeywords = calendarKeywords.some(keyword => lowerQuery.includes(keyword));
    
    // Determine query type
    const matchCount = [hasNotionKeywords, hasEmailKeywords, hasCalendarKeywords].filter(Boolean).length;
    
    if (matchCount > 1) return 'mixed';
    if (hasNotionKeywords) return 'notion';
    if (hasEmailKeywords) return 'email';
    if (hasCalendarKeywords) return 'calendar';
    
    return 'research'; // Default to web research
  }
  
  private async handleNotionQuery(query: string): Promise<any[]> {
    try {
      if (query.toLowerCase().includes('save to notion') || query.toLowerCase().includes('create')) {
        // Handle create operations
        return [];
      } else {
        // Search existing pages
        const result = await notionService.searchPages(query, 5);
        return result.pages;
      }
    } catch (error) {
      console.error('Notion query error:', error);
      return [];
    }
  }
  
  private async handleEmailQuery(query: string): Promise<any[]> {
    try {
      if (query.toLowerCase().includes('recent') || query.toLowerCase().includes('latest')) {
        return await outlookService.getRecentEmails(5);
      } else {
        return await outlookService.searchEmails(query, 5);
      }
    } catch (error) {
      console.error('Email query error:', error);
      return [];
    }
  }
  
  private async handleCalendarQuery(query: string): Promise<any[]> {
    try {
      if (query.toLowerCase().includes('upcoming') || query.toLowerCase().includes('next')) {
        return await outlookService.getUpcomingEvents(5);
      } else {
        return await outlookService.searchCalendarEvents(query, 5);
      }
    } catch (error) {
      console.error('Calendar query error:', error);
      return [];
    }
  }
  
  private formatNotionSummary(pages: any[], query: string): string {
    if (pages.length === 0) {
      return `## Notion Search Results\n\nNo documents found for "${query}". You may want to:\n- Check your spelling\n- Try different keywords\n- Create a new document if needed`;
    }
    
    let summary = `## Notion Documents\n\nFound ${pages.length} document${pages.length > 1 ? 's' : ''} related to "${query}":\n\n`;
    
    pages.forEach((page, index) => {
      summary += `### ${index + 1}. ${page.title}\n`;
      summary += `- **Last edited:** ${new Date(page.lastEditedTime).toLocaleDateString()}\n`;
      summary += `- **Link:** [Open in Notion](${page.url})\n\n`;
    });
    
    return summary;
  }
  
  private formatEmailSummary(emails: any[], query: string): string {
    if (emails.length === 0) {
      return `## Email Search Results\n\nNo emails found for "${query}".`;
    }
    
    let summary = `## Email Messages\n\nFound ${emails.length} email${emails.length > 1 ? 's' : ''} related to "${query}":\n\n`;
    
    emails.forEach((email, index) => {
      summary += `### ${index + 1}. ${email.subject}\n`;
      summary += `- **From:** ${email.from}\n`;
      summary += `- **Received:** ${new Date(email.receivedDateTime).toLocaleDateString()}\n`;
      summary += `- **Preview:** ${email.bodyPreview.substring(0, 100)}...\n`;
      summary += `- **Status:** ${email.isRead ? 'Read' : 'Unread'}\n\n`;
    });
    
    return summary;
  }
  
  private formatCalendarSummary(events: any[], query: string): string {
    if (events.length === 0) {
      return `## Calendar Events\n\nNo events found for "${query}".`;
    }
    
    let summary = `## Calendar Events\n\nFound ${events.length} event${events.length > 1 ? 's' : ''} related to "${query}":\n\n`;
    
    events.forEach((event, index) => {
      summary += `### ${index + 1}. ${event.subject}\n`;
      summary += `- **Date:** ${new Date(event.start).toLocaleDateString()}\n`;
      summary += `- **Time:** ${new Date(event.start).toLocaleTimeString()} - ${new Date(event.end).toLocaleTimeString()}\n`;
      if (event.location) summary += `- **Location:** ${event.location}\n`;
      summary += `- **Organizer:** ${event.organizer}\n\n`;
    });
    
    return summary;
  }
  
  private formatMixedSummary(notionPages: any[], emails: any[], events: any[], query: string): string {
    let summary = `## Search Results for "${query}"\n\n`;
    
    if (notionPages.length > 0) {
      summary += `### Notion Documents (${notionPages.length})\n`;
      notionPages.slice(0, 3).forEach((page, index) => {
        summary += `- **${page.title}** (edited ${new Date(page.lastEditedTime).toLocaleDateString()})\n`;
      });
      summary += '\n';
    }
    
    if (emails.length > 0) {
      summary += `### Email Messages (${emails.length})\n`;
      emails.slice(0, 3).forEach((email, index) => {
        summary += `- **${email.subject}** from ${email.from} (${new Date(email.receivedDateTime).toLocaleDateString()})\n`;
      });
      summary += '\n';
    }
    
    if (events.length > 0) {
      summary += `### Calendar Events (${events.length})\n`;
      events.slice(0, 3).forEach((event, index) => {
        summary += `- **${event.subject}** on ${new Date(event.start).toLocaleDateString()}\n`;
      });
      summary += '\n';
    }
    
    if (notionPages.length === 0 && emails.length === 0 && events.length === 0) {
      summary += 'No results found in your connected services. Try adjusting your search terms or checking your integrations.';
    }
    
    return summary;
  }
}

export const enhancedResearchService = new EnhancedResearchService();