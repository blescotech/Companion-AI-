import { getUncachableNotionClient } from '../integrations/notion';

export interface NotionPage {
  id: string;
  title: string;
  url: string;
  lastEditedTime: string;
  properties?: Record<string, any>;
}

export interface NotionSearchResult {
  pages: NotionPage[];
  totalCount: number;
}

export class NotionService {
  async searchPages(query: string, limit: number = 10): Promise<NotionSearchResult> {
    try {
      const notion = await getUncachableNotionClient();
      
      const response = await notion.search({
        query,
        page_size: limit,
        filter: {
          property: 'object',
          value: 'page'
        }
      });

      const pages: NotionPage[] = response.results
        .filter((result: any) => result.object === 'page')
        .map((page: any) => ({
          id: page.id,
          title: this.extractTitle(page),
          url: page.url,
          lastEditedTime: page.last_edited_time,
          properties: page.properties
        }));

      return {
        pages,
        totalCount: response.results.length
      };
    } catch (error: any) {
      console.error('Notion search error:', error);
      throw new Error(`Failed to search Notion: ${error.message}`);
    }
  }

  async createPage(title: string, content: string, parentPageId?: string): Promise<NotionPage> {
    try {
      const notion = await getUncachableNotionClient();
      
      const createPageData: any = {
        parent: parentPageId 
          ? { page_id: parentPageId }
          : { type: 'page_id', page_id: 'root' }, // This would need the actual workspace root
        properties: {
          title: {
            title: [
              {
                text: {
                  content: title
                }
              }
            ]
          }
        },
        children: [
          {
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: content
                  }
                }
              ]
            }
          }
        ]
      };

      const response = await notion.pages.create(createPageData);
      
      return {
        id: response.id,
        title,
        url: `https://notion.so/${response.id.replace(/-/g, '')}`,
        lastEditedTime: new Date().toISOString(),
        properties: (response as any).properties
      };
    } catch (error: any) {
      console.error('Notion create page error:', error);
      throw new Error(`Failed to create Notion page: ${error.message}`);
    }
  }

  async getRecentPages(limit: number = 10): Promise<NotionPage[]> {
    try {
      const notion = await getUncachableNotionClient();
      
      const response = await notion.search({
        page_size: limit,
        sort: {
          direction: 'descending',
          timestamp: 'last_edited_time'
        },
        filter: {
          property: 'object',
          value: 'page'
        }
      });

      return response.results
        .filter((result: any) => result.object === 'page')
        .map((page: any) => ({
          id: page.id,
          title: this.extractTitle(page),
          url: page.url,
          lastEditedTime: page.last_edited_time,
          properties: page.properties
        }));
    } catch (error: any) {
      console.error('Notion get recent pages error:', error);
      throw new Error(`Failed to get recent Notion pages: ${error.message}`);
    }
  }

  private extractTitle(page: any): string {
    if (page.properties?.title?.title?.[0]?.text?.content) {
      return page.properties.title.title[0].text.content;
    }
    if (page.properties?.Name?.title?.[0]?.text?.content) {
      return page.properties.Name.title[0].text.content;
    }
    return 'Untitled';
  }
}

export const notionService = new NotionService();