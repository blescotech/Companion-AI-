export interface SearchResult {
  title: string;
  snippet: string;
  link: string;
}

export interface ResearchResponse {
  heard: string;
  summary: string;
  sourceCount: string;
  processingTime: string;
}

export class ResearchService {
  private serpApiKey: string;
  private geminiApiKey: string;

  constructor() {
    this.serpApiKey = process.env.SERPAPI_KEY || process.env.SERP_API_KEY || "";
    this.geminiApiKey = process.env.GEMINI_API_KEY || "";

    if (!this.serpApiKey) {
      throw new Error("SERPAPI_KEY environment variable is required");
    }
    if (!this.geminiApiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
  }

  async searchWeb(query: string): Promise<SearchResult[]> {
    const serpUrl = `https://serpapi.com/search.json?q=${encodeURIComponent(query)}&api_key=${this.serpApiKey}`;
    
    const response = await fetch(serpUrl);
    if (!response.ok) {
      throw new Error(`SerpAPI request failed: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.error) {
      throw new Error(`SerpAPI error: ${data.error}`);
    }

    const results: SearchResult[] = (data.organic_results || [])
      .slice(0, 5)
      .map((result: any) => ({
        title: result.title || "",
        snippet: result.snippet || "",
        link: result.link || "",
      }));

    return results;
  }

  async generateSummary(searchResults: SearchResult[], originalQuery: string): Promise<string> {
    const searchContent = searchResults
      .map(result => `${result.title}: ${result.snippet}`)
      .join("\n\n");

    const prompt = `Based on the following search results about "${originalQuery}", create a comprehensive and well-structured summary. Format your response with clear sections and bullet points for easy reading.

Search Results:
${searchContent}

Please provide a detailed summary using this structure:
## Overview
- Brief introduction to the topic

## Key Findings
- Main insights and facts (use bullet points)
- Important developments and trends
- Notable statistics or data points

## Current Developments
- Recent changes or innovations
- Emerging trends or technologies
- Market developments

## Future Outlook
- Expected developments or predictions
- Potential impacts or implications

Use clear formatting with headers (##) and bullet points (-) to make the information easy to scan and read. Keep each bullet point concise but informative.`;

    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${this.geminiApiKey}`;
    
    const response = await fetch(geminiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API request failed: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (data.error) {
      throw new Error(`Gemini API error: ${data.error.message}`);
    }

    const summary = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!summary) {
      throw new Error("No summary generated from Gemini API");
    }

    return summary;
  }

  async performResearch(query: string): Promise<ResearchResponse> {
    const startTime = Date.now();

    try {
      // Step 1: Search using SerpAPI
      const searchResults = await this.searchWeb(query);
      
      if (searchResults.length === 0) {
        throw new Error("No search results found for your query");
      }

      // Step 2: Generate summary using Gemini
      const summary = await this.generateSummary(searchResults, query);

      const processingTime = ((Date.now() - startTime) / 1000).toFixed(1);

      return {
        heard: query,
        summary,
        sourceCount: searchResults.length.toString(),
        processingTime: `${processingTime}s`,
      };
    } catch (error) {
      console.error("Research error:", error);
      throw new Error(
        error instanceof Error 
          ? error.message 
          : "An unexpected error occurred during research"
      );
    }
  }
}
