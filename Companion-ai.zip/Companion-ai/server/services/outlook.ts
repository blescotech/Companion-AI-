import { getUncachableOutlookClient } from '../integrations/outlook';

export interface EmailMessage {
  id: string;
  subject: string;
  from: string;
  receivedDateTime: string;
  bodyPreview: string;
  isRead: boolean;
  webLink: string;
}

export interface CalendarEvent {
  id: string;
  subject: string;
  start: string;
  end: string;
  location?: string;
  organizer: string;
  webLink: string;
  isAllDay: boolean;
}

export interface OutlookSearchResult {
  emails: EmailMessage[];
  events: CalendarEvent[];
}

export class OutlookService {
  async searchEmails(query: string, limit: number = 10): Promise<EmailMessage[]> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const messages = await graphClient
        .me
        .messages
        .get({
          $search: `"${query}"`,
          $top: limit,
          $select: 'id,subject,from,receivedDateTime,bodyPreview,isRead,webLink',
          $orderby: 'receivedDateTime desc'
        });

      return messages.value?.map((message: any) => ({
        id: message.id,
        subject: message.subject || 'No Subject',
        from: message.from?.emailAddress?.address || 'Unknown',
        receivedDateTime: message.receivedDateTime,
        bodyPreview: message.bodyPreview || '',
        isRead: message.isRead || false,
        webLink: message.webLink || ''
      })) || [];
    } catch (error: any) {
      console.error('Outlook email search error:', error);
      throw new Error(`Failed to search emails: ${error.message}`);
    }
  }

  async getRecentEmails(limit: number = 10): Promise<EmailMessage[]> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const messages = await graphClient
        .me
        .messages
        .get({
          $top: limit,
          $select: 'id,subject,from,receivedDateTime,bodyPreview,isRead,webLink',
          $orderby: 'receivedDateTime desc'
        });

      return messages.value?.map((message: any) => ({
        id: message.id,
        subject: message.subject || 'No Subject',
        from: message.from?.emailAddress?.address || 'Unknown',
        receivedDateTime: message.receivedDateTime,
        bodyPreview: message.bodyPreview || '',
        isRead: message.isRead || false,
        webLink: message.webLink || ''
      })) || [];
    } catch (error: any) {
      console.error('Outlook get recent emails error:', error);
      throw new Error(`Failed to get recent emails: ${error.message}`);
    }
  }

  async searchCalendarEvents(query: string, limit: number = 10): Promise<CalendarEvent[]> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const events = await graphClient
        .me
        .events
        .get({
          $search: `"${query}"`,
          $top: limit,
          $select: 'id,subject,start,end,location,organizer,webLink,isAllDay',
          $orderby: 'start/dateTime asc'
        });

      return events.value?.map((event: any) => ({
        id: event.id,
        subject: event.subject || 'No Subject',
        start: event.start?.dateTime || '',
        end: event.end?.dateTime || '',
        location: event.location?.displayName || '',
        organizer: event.organizer?.emailAddress?.address || 'Unknown',
        webLink: event.webLink || '',
        isAllDay: event.isAllDay || false
      })) || [];
    } catch (error: any) {
      console.error('Outlook calendar search error:', error);
      throw new Error(`Failed to search calendar events: ${error.message}`);
    }
  }

  async getUpcomingEvents(limit: number = 10): Promise<CalendarEvent[]> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const now = new Date().toISOString();
      const events = await graphClient
        .me
        .events
        .get({
          $top: limit,
          $select: 'id,subject,start,end,location,organizer,webLink,isAllDay',
          $filter: `start/dateTime ge '${now}'`,
          $orderby: 'start/dateTime asc'
        });

      return events.value?.map((event: any) => ({
        id: event.id,
        subject: event.subject || 'No Subject',
        start: event.start?.dateTime || '',
        end: event.end?.dateTime || '',
        location: event.location?.displayName || '',
        organizer: event.organizer?.emailAddress?.address || 'Unknown',
        webLink: event.webLink || '',
        isAllDay: event.isAllDay || false
      })) || [];
    } catch (error: any) {
      console.error('Outlook get upcoming events error:', error);
      throw new Error(`Failed to get upcoming events: ${error.message}`);
    }
  }

  async createCalendarEvent(
    subject: string,
    start: string,
    end: string,
    location?: string,
    attendees?: string[]
  ): Promise<CalendarEvent> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const eventData: any = {
        subject,
        start: {
          dateTime: start,
          timeZone: 'UTC'
        },
        end: {
          dateTime: end,
          timeZone: 'UTC'
        }
      };

      if (location) {
        eventData.location = {
          displayName: location
        };
      }

      if (attendees && attendees.length > 0) {
        eventData.attendees = attendees.map(email => ({
          emailAddress: {
            address: email
          }
        }));
      }

      const event = await graphClient
        .me
        .events
        .post(eventData);

      return {
        id: event.id,
        subject: event.subject || 'No Subject',
        start: event.start?.dateTime || '',
        end: event.end?.dateTime || '',
        location: event.location?.displayName || '',
        organizer: event.organizer?.emailAddress?.address || 'Unknown',
        webLink: event.webLink || '',
        isAllDay: event.isAllDay || false
      };
    } catch (error: any) {
      console.error('Outlook create event error:', error);
      throw new Error(`Failed to create calendar event: ${error.message}`);
    }
  }

  async sendEmail(
    to: string[],
    subject: string,
    body: string,
    cc?: string[],
    bcc?: string[]
  ): Promise<void> {
    try {
      const graphClient = await getUncachableOutlookClient();
      
      const message: any = {
        subject,
        body: {
          contentType: 'Text',
          content: body
        },
        toRecipients: to.map(email => ({
          emailAddress: {
            address: email
          }
        }))
      };

      if (cc && cc.length > 0) {
        message.ccRecipients = cc.map(email => ({
          emailAddress: {
            address: email
          }
        }));
      }

      if (bcc && bcc.length > 0) {
        message.bccRecipients = bcc.map(email => ({
          emailAddress: {
            address: email
          }
        }));
      }

      await graphClient
        .me
        .sendMail({
          message,
          saveToSentItems: true
        })
        .post();
    } catch (error: any) {
      console.error('Outlook send email error:', error);
      throw new Error(`Failed to send email: ${error.message}`);
    }
  }
}

export const outlookService = new OutlookService();