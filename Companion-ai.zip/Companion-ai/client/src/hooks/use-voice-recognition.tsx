import { useState, useCallback, useRef } from "react";

interface VoiceRecognitionOptions {
  onResult: (text: string) => void;
  onError: (error: string) => void;
  language?: string;
}

export function useVoiceRecognition({
  onResult,
  onError,
  language = "en-US",
}: VoiceRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  const startListening = useCallback(() => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      setIsSupported(false);
      onError("Voice recognition is not supported in this browser. Please try Chrome or Edge.");
      return;
    }

    try {
      const SpeechRecognition = 
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      
      recognitionRef.current = new SpeechRecognition();
      const recognition = recognitionRef.current;

      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        onResult(text);
        setIsListening(false);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
        
        let errorMessage = "Voice recognition failed. Please try again.";
        
        switch (event.error) {
          case "network":
            errorMessage = "Network error. Please check your internet connection.";
            break;
          case "not-allowed":
            errorMessage = "Microphone access denied. Please allow microphone permissions.";
            break;
          case "no-speech":
            errorMessage = "No speech detected. Please try speaking closer to the microphone.";
            break;
          case "audio-capture":
            errorMessage = "Microphone not found. Please check your microphone connection.";
            break;
        }
        
        onError(errorMessage);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (error) {
      console.error("Failed to start voice recognition:", error);
      onError("Failed to start voice recognition. Please try again.");
      setIsListening(false);
    }
  }, [onResult, onError, language]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  }, []);

  return {
    isListening,
    isSupported,
    startListening,
    stopListening,
  };
}
