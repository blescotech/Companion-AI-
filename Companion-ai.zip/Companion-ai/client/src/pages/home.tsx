import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useVoiceRecognition } from "@/hooks/use-voice-recognition";
import { researchApi, type ResearchResponse, type RecentQuery } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Mic, 
  MicOff, 
  Loader2, 
  Search, 
  FileText, 
  Calendar, 
  Mail, 
  Bookmark,
  User,
  Bell,
  Send,
  Clock
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";

const suggestedQueries = [
  "Summarize latest AI news",
  "Create a meeting for tomorrow", 
  "Find research on climate tech"
];

const sidebarItems = [
  { icon: Mic, label: "Voice Search", active: true },
  { icon: Search, label: "Web Search", active: false },
  { icon: FileText, label: "Documents", active: false },
  { icon: Bookmark, label: "Notion", active: false },
  { icon: Mail, label: "Email", active: false },
  { icon: Calendar, label: "Calendar", active: false },
];

export default function Home() {
  const [currentQuery, setCurrentQuery] = useState<string>("");
  const [textQuery, setTextQuery] = useState<string>("");
  const [searchResults, setSearchResults] = useState<ResearchResponse[]>([]);
  const [error, setError] = useState<string>("");
  const { toast } = useToast();

  const { data: recentQueries = [] } = useQuery<RecentQuery[]>({
    queryKey: ["/api/recent-queries"],
  });

  const researchMutation = useMutation({
    mutationFn: researchApi.performResearch,
    onSuccess: (data) => {
      // Add the original query to the result for display
      const resultWithQuery = { 
        ...data, 
        query: currentQuery,
        createdAt: new Date()
      };
      setSearchResults(prev => [resultWithQuery, ...prev]);
      setError("");
      setCurrentQuery("");
      setTextQuery("");
      queryClient.invalidateQueries({ queryKey: ["/api/recent-queries"] });
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Failed to process your research request";
      setError(errorMessage);
    },
  });

  const handleVoiceResult = (text: string) => {
    setCurrentQuery(text);
    setTextQuery(text);
    setError("");
    researchMutation.mutate(text);
  };

  const handleVoiceError = (errorMessage: string) => {
    setError(errorMessage);
  };

  const { isListening, isSupported, startListening, stopListening } = useVoiceRecognition({
    onResult: handleVoiceResult,
    onError: handleVoiceError,
  });

  const handleSuggestedQuery = (query: string) => {
    setCurrentQuery(query);
    setTextQuery(query);
    setError("");
    researchMutation.mutate(query);
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textQuery.trim()) return;
    
    setCurrentQuery(textQuery.trim());
    setError("");
    researchMutation.mutate(textQuery.trim());
  };

  const handleTextQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTextQuery(e.target.value);
  };

  const formatTimeAgo = (date: Date | null | string) => {
    if (!date) return "Unknown";
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(dateObj.getTime())) return "Unknown";
    
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - dateObj.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  const formatDateTime = (date: Date | null | string) => {
    if (!date) return "";
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    if (isNaN(dateObj.getTime())) return "";
    
    return dateObj.toLocaleString('en-US', {
      month: 'numeric',
      day: 'numeric', 
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatSummary = (summary: string) => {
    const lines = summary.split('\n').filter(line => line.trim() !== '');
    const formattedContent = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (line.startsWith('## ')) {
        formattedContent.push(
          <h3 key={i} className="text-lg font-semibold text-gray-900 mt-4 mb-2 first:mt-0">
            {line.replace('## ', '')}
          </h3>
        );
      } else if (line.startsWith('- ')) {
        formattedContent.push(
          <div key={i} className="flex items-start space-x-2 mb-2">
            <div className="w-1.5 h-1.5 bg-gray-600 rounded-full mt-2 flex-shrink-0"></div>
            <span className="text-gray-800 leading-relaxed">{line.replace('- ', '')}</span>
          </div>
        );
      } else if (line.length > 0) {
        formattedContent.push(
          <p key={i} className="text-gray-800 leading-relaxed mb-3">
            {line}
          </p>
        );
      }
    }
    
    return formattedContent;
  };

  return (
    <div className="h-screen bg-white flex">
      {/* Sidebar */}
      <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <span className="text-white text-sm font-bold">AI</span>
            </div>
            <span className="text-lg font-medium text-gray-900">AI Assistant</span>
          </div>
        </div>
        
        {/* Navigation */}
        <div className="flex-1 p-4">
          <nav className="space-y-2">
            {sidebarItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div
                  key={index}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                    item.active 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                  data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
                >
                  <Icon size={20} />
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
              );
            })}
          </nav>
          
          {/* Recent Activity */}
          <div className="mt-8">
            <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
              RECENT ACTIVITY
            </h3>
            {recentQueries.slice(0, 3).map((query, index) => (
              <div key={query.id} className="mb-3 cursor-pointer" data-testid={`recent-query-${index}`}>
                <p className="text-sm text-gray-900 mb-1 line-clamp-2">{query.query}</p>
                <p className="text-xs text-gray-500">{formatTimeAgo(query.createdAt)}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* System Status */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">All systems operational</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Bell size={20} className="text-gray-400" data-testid="notifications-bell" />
              <User size={20} className="text-gray-400" data-testid="user-profile" />
            </div>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          {/* Main Interface - Only show when no results */}
          {searchResults.length === 0 && (
            <div className="max-w-2xl mx-auto text-center">
              <h1 className="text-4xl font-normal text-gray-900 mb-4" data-testid="main-heading">
                AI-Powered Voice Assistant
              </h1>
              <p className="text-lg text-gray-600 mb-12" data-testid="main-subtitle">
                Speak naturally to search, research, and manage your tasks
              </p>
              
              {/* Voice Button */}
              <div className="mb-8">
                {!isSupported ? (
                  <Button 
                    disabled
                    className="w-24 h-24 bg-gray-400 text-white rounded-full shadow-lg"
                    data-testid="mic-button-disabled"
                  >
                    <MicOff size={32} />
                  </Button>
                ) : isListening ? (
                  <Button 
                    onClick={stopListening}
                    className="w-24 h-24 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-pulse"
                    data-testid="mic-button-listening"
                  >
                    <Mic size={32} />
                  </Button>
                ) : researchMutation.isPending ? (
                  <Button 
                    disabled
                    className="w-24 h-24 bg-blue-500 text-white rounded-full shadow-lg animate-pulse"
                    data-testid="mic-button-processing"
                  >
                    <Loader2 className="animate-spin" size={32} />
                  </Button>
                ) : (
                  <Button 
                    onClick={startListening}
                    className="w-24 h-24 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                    data-testid="mic-button-ready"
                  >
                    <Mic size={32} />
                  </Button>
                )}
              </div>
              
              <p className="text-gray-600 mb-8" data-testid="mic-status">
                {isListening 
                  ? "Listening..." 
                  : researchMutation.isPending 
                  ? "Processing..." 
                  : "Click to start listening"
                }
              </p>

              {/* Text Input */}
              <form onSubmit={handleTextSubmit} className="w-full max-w-2xl mx-auto mb-8">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Or type your query here..."
                    value={textQuery}
                    onChange={handleTextQueryChange}
                    disabled={researchMutation.isPending}
                    className="w-full h-12 pr-12 text-base border-gray-300 rounded-full focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    data-testid="text-input"
                  />
                  <Button 
                    type="submit" 
                    disabled={!textQuery.trim() || researchMutation.isPending}
                    size="sm"
                    className="absolute right-2 top-2 w-8 h-8 bg-blue-500 hover:bg-blue-600 text-white rounded-full p-0"
                    data-testid="send-button"
                  >
                    {researchMutation.isPending ? (
                      <Loader2 className="animate-spin" size={16} />
                    ) : (
                      <Send size={16} />
                    )}
                  </Button>
                </div>
              </form>
              
              {/* Suggested Queries */}
              <div className="flex flex-wrap justify-center gap-3">
                {suggestedQueries.map((query, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSuggestedQuery(query)}
                    disabled={researchMutation.isPending}
                    className="rounded-full border-gray-300 text-gray-700 hover:bg-gray-50"
                    data-testid={`suggested-query-${index}`}
                  >
                    {query}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {searchResults.length > 0 && (
            <div className="flex-1 overflow-y-auto p-8 w-full">
              <div className="max-w-4xl mx-auto">
                <div className="mb-6 flex items-center justify-between">
                  <h2 className="text-2xl font-semibold text-gray-900" data-testid="search-results-heading">
                    Search Results
                  </h2>
                  <Button variant="ghost" size="sm" className="text-gray-500 flex items-center gap-2">
                    <Bookmark size={16} />
                    Save to Notion
                  </Button>
                </div>
                
                {searchResults.map((result, index) => (
                  <Card key={index} className="mb-6" data-testid={`search-result-${index}`}>
                    <CardContent className="p-6">
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-gray-700">
                            Query: {currentQuery || result.query || "Research query"}
                          </span>
                          <span className="text-sm text-gray-500">
                            {formatDateTime(new Date())}
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Intent: search</span>
                          <span className="px-2 py-1 bg-gray-100 rounded text-xs">
                            research assistant
                          </span>
                        </div>
                      </div>
                      <div className="prose max-w-none">
                        {formatSummary(result.summary)}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          {/* Processing Indicator */}
          {researchMutation.isPending && searchResults.length === 0 && (
            <div className="flex items-center justify-center p-8">
              <div className="flex items-center space-x-3">
                <Loader2 className="animate-spin text-blue-500" size={24} />
                <span className="text-gray-600">Processing your request...</span>
              </div>
            </div>
          )}
          
          {/* Error Display */}
          {error && (
            <div className="p-8">
              <Card className="border-red-200 bg-red-50">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="text-red-500">⚠️</div>
                    <div>
                      <h4 className="font-semibold text-red-900 mb-2">Error</h4>
                      <p className="text-red-800">{error}</p>
                      <Button 
                        onClick={() => setError("")}
                        size="sm"
                        className="mt-3 bg-red-500 hover:bg-red-600 text-white"
                      >
                        Dismiss
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}