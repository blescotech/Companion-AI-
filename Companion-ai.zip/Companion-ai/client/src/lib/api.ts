import { apiRequest } from "./queryClient";

export interface ResearchResponse {
  query?: string;
  heard: string;
  summary: string;
  sourceCount: string;
  processingTime: string;
  createdAt?: Date;
}

export interface ResearchError {
  error: string;
  heard: string;
}

export interface RecentQuery {
  id: string;
  query: string;
  summary: string;
  sourceCount: string | null;
  processingTime: string | null;
  createdAt: Date | null;
}

export const researchApi = {
  async performResearch(query: string): Promise<ResearchResponse> {
    const response = await apiRequest("POST", "/api/research", { query });
    return response.json();
  },

  async getRecentQueries(limit = 5): Promise<RecentQuery[]> {
    const response = await apiRequest("GET", `/api/recent-queries?limit=${limit}`);
    return response.json();
  },
};
