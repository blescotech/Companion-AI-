# Overview

This is a Companion AI Research Summary application - an AI-powered research assistant that converts spoken queries into intelligent summaries using real-time web search and advanced AI technology. Users can speak or type research questions, and the application performs web searches via SerpAPI, then uses Google's Gemini AI to generate comprehensive summaries of the findings.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack Query for server state management and data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Voice Recognition**: Web Speech API integration with browser compatibility checks

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Architecture Pattern**: RESTful API with service layer pattern
- **Request Handling**: Express middleware for JSON parsing, CORS, and request logging
- **Services**: Dedicated ResearchService for handling search and AI operations
- **Error Handling**: Centralized error handling with proper HTTP status codes

## Data Storage Solutions
- **Primary Database**: PostgreSQL configured with Drizzle ORM
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Fallback Storage**: In-memory storage implementation for development/testing
- **Session Management**: PostgreSQL session store using connect-pg-simple

## Authentication and Authorization
- **Session-based Authentication**: Express sessions with PostgreSQL storage
- **User Management**: Basic user registration and login system
- **Password Security**: Standard password hashing (implementation details in user service)

## External Dependencies

### Third-party APIs
- **SerpAPI**: Web search functionality for gathering research data
- **Google Gemini AI**: Natural language processing and summary generation
- **Neon Database**: Serverless PostgreSQL hosting

### Key Libraries and Frameworks
- **Frontend**: React 18, Vite, TanStack Query, Wouter, Shadcn/ui, Radix UI
- **Backend**: Express.js, Drizzle ORM, TypeScript
- **Development**: ESBuild for server bundling, PostCSS for CSS processing
- **Voice**: Browser Web Speech API for voice recognition capabilities

### Database and Infrastructure
- **Database**: PostgreSQL with Drizzle ORM and Neon serverless hosting
- **Environment**: Replit hosting with environment variable configuration
- **Build System**: Vite for frontend, ESBuild for backend production builds